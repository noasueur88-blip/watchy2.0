// ── Navigation ──────────────────────────────────────────────────────────────
const titles = {
  stats:      'Statistiques',
  servers:    'Serveurs',
  commands:   'Commandes',
  members:    'Membres',
  moderation: 'Modération',
  bans:       'Bans',
  config:     'Configuration',
};

document.querySelectorAll('.nav-item').forEach(el => {
  el.addEventListener('click', e => {
    e.preventDefault();
    const panel = el.dataset.panel;
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    el.classList.add('active');
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    document.getElementById('panel-' + panel).classList.add('active');
    document.getElementById('page-title').textContent = titles[panel] || panel;
    onPanelChange(panel);
  });
});

// ── State ────────────────────────────────────────────────────────────────────
let currentGuild = null;

// ── API helpers ───────────────────────────────────────────────────────────────
async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  if (!res.ok) return null;
  return res.json();
}

// ── Init ─────────────────────────────────────────────────────────────────────
async function init() {
  loadStats();
  loadGuilds();
  checkConfig();
}

// ── Stats ─────────────────────────────────────────────────────────────────────
async function loadStats() {
  const data = await api('/api/stats');
  if (!data) return;
  document.getElementById('s-guilds').textContent  = data.guilds ?? '—';
  document.getElementById('s-users').textContent   = data.users ?? '—';
  document.getElementById('s-cmds').textContent    = data.commands_today ?? '—';
  document.getElementById('s-latency').textContent = data.latency ?? '—';
}

// ── Guilds ────────────────────────────────────────────────────────────────────
async function loadGuilds() {
  const guilds = await api('/api/guilds');
  const listEl = document.getElementById('guild-list');
  const sel = document.getElementById('guild-select');

  if (!guilds || !guilds.length) {
    listEl.innerHTML = '<div class="loading">Aucun serveur trouvé.</div>';
    return;
  }

  // Populate sidebar list
  listEl.innerHTML = guilds.map(g => {
    const icon = g.icon
      ? `<img src="https://cdn.discordapp.com/icons/${g.id}/${g.icon}.png" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">`
      : `<span style="font-size:20px;">🌐</span>`;
    const badge = g.owner
      ? `<span class="badge admin" style="margin-left:auto">Owner</span>`
      : `<span class="badge" style="margin-left:auto;background:var(--bg3);color:var(--muted)">Membre</span>`;
    return `<div class="server-row">
      <div class="server-icon">${icon}</div>
      <div>
        <div class="server-name">${escHtml(g.name)}</div>
        <div class="server-members">ID: ${g.id}</div>
      </div>
      ${badge}
    </div>`;
  }).join('');

  // Populate select
  sel.innerHTML = '<option value="">— Choisir un serveur —</option>' +
    guilds.map(g => `<option value="${g.id}">${escHtml(g.name)}</option>`).join('');
}

// ── Guild change ───────────────────────────────────────────────────────────────
function onGuildChange(gid) {
  currentGuild = gid || null;
  const active = document.querySelector('.panel.active');
  if (active) onPanelChange(active.id.replace('panel-', ''));
}

function onPanelChange(panel) {
  if (panel === 'commands') loadCommands();
  if (panel === 'members')  loadMembers();
  if (panel === 'bans')     loadBans();
}

// ── Commands ─────────────────────────────────────────────────────────────────
async function loadCommands() {
  const msg  = document.getElementById('cmd-msg');
  const wrap = document.getElementById('cmd-table-wrap');
  const body = document.getElementById('cmd-body');
  if (!currentGuild) { msg.style.display=''; wrap.style.display='none'; return; }
  msg.style.display = 'none';
  wrap.style.display = '';
  body.innerHTML = '<tr><td colspan="3" class="loading">Chargement…</td></tr>';
  const cmds = await api(`/api/guild/${currentGuild}/commands`);
  if (!cmds || !cmds.length) { body.innerHTML = '<tr><td colspan="3" class="loading">Aucune commande enregistrée.</td></tr>'; return; }
  body.innerHTML = cmds.map(c => `<tr>
    <td><code>/${escHtml(c.name)}</code></td>
    <td style="color:var(--muted)">${escHtml(c.description || '—')}</td>
    <td><span class="badge enabled">${c.type === 1 ? 'Slash' : 'Menu'}</span></td>
  </tr>`).join('');
}

// ── Members ───────────────────────────────────────────────────────────────────
async function loadMembers() {
  const msg  = document.getElementById('members-msg');
  const wrap = document.getElementById('members-table-wrap');
  const body = document.getElementById('members-body');
  if (!currentGuild) { msg.style.display=''; wrap.style.display='none'; return; }
  msg.style.display = 'none';
  wrap.style.display = '';
  body.innerHTML = '<tr><td colspan="5" class="loading">Chargement…</td></tr>';
  const members = await api(`/api/guild/${currentGuild}/members?limit=50`);
  if (!members || !members.length) { body.innerHTML = '<tr><td colspan="5" class="loading">Aucun membre trouvé.</td></tr>'; return; }
  body.innerHTML = members.map(m => {
    const joined = m.joined_at ? new Date(m.joined_at).toLocaleDateString('fr-FR') : '—';
    const roles  = m.roles.length ? `<span class="badge mod">${m.roles.length} rôle(s)</span>` : '—';
    return `<tr>
      <td>${escHtml(m.username)}<span style="color:var(--muted)">#${m.discriminator}</span></td>
      <td style="color:var(--muted)">${escHtml(m.nick || '—')}</td>
      <td style="color:var(--muted)">${joined}</td>
      <td>${roles}</td>
      <td>
        <button class="btn danger" onclick="kickMember('${m.id}','${escHtml(m.username)}')">Kick</button>
      </td>
    </tr>`;
  }).join('');
}

async function kickMember(uid, uname) {
  if (!currentGuild) return;
  if (!confirm(`Kick ${uname} ?`)) return;
  const r = await api(`/api/guild/${currentGuild}/kick/${uid}`, { method: 'POST' });
  if (r?.success) { showToast(`${uname} a été kick.`, 'ok'); loadMembers(); }
  else showToast('Erreur lors du kick.', 'err');
}

// ── Bans ──────────────────────────────────────────────────────────────────────
async function loadBans() {
  const msg  = document.getElementById('bans-msg');
  const wrap = document.getElementById('bans-wrap');
  const body = document.getElementById('bans-body');
  if (!currentGuild) { msg.style.display=''; wrap.style.display='none'; return; }
  msg.style.display = 'none';
  wrap.style.display = '';
  body.innerHTML = '<tr><td colspan="3" class="loading">Chargement…</td></tr>';
  const bans = await api(`/api/guild/${currentGuild}/bans`);
  if (!bans || !bans.length) { body.innerHTML = '<tr><td colspan="3" class="loading">Aucun ban.</td></tr>'; return; }
  body.innerHTML = bans.map(b => `<tr>
    <td>${escHtml(b.user?.username || b.user?.id || '—')}</td>
    <td style="color:var(--muted)">${escHtml(b.reason || 'Aucune raison')}</td>
    <td><button class="btn primary" onclick="doUnban('${b.user?.id}')">Débannir</button></td>
  </tr>`).join('');
}

async function doUnban(uid) {
  if (!currentGuild) return;
  const r = await api(`/api/guild/${currentGuild}/ban/${uid}`, { method: 'DELETE' });
  if (r?.success) { showToast('Utilisateur débanni.', 'ok'); loadBans(); }
  else showToast('Erreur lors du déban.', 'err');
}

// ── Moderation actions ────────────────────────────────────────────────────────
async function doKick() {
  const uid = document.getElementById('kick-uid').value.trim();
  const res = document.getElementById('kick-result');
  if (!uid || !currentGuild) { res.textContent = 'Sélectionnez un serveur et entrez un ID.'; res.className = 'action-result err'; return; }
  const r = await api(`/api/guild/${currentGuild}/kick/${uid}`, { method: 'POST' });
  if (r?.success) { res.textContent = 'Utilisateur kick avec succès.'; res.className = 'action-result ok'; }
  else { res.textContent = 'Erreur : vérifiez l\'ID et les permissions du bot.'; res.className = 'action-result err'; }
}

async function doBan() {
  const uid    = document.getElementById('ban-uid').value.trim();
  const reason = document.getElementById('ban-reason').value.trim();
  const res    = document.getElementById('ban-result');
  if (!uid || !currentGuild) { res.textContent = 'Sélectionnez un serveur et entrez un ID.'; res.className = 'action-result err'; return; }
  const r = await api(`/api/guild/${currentGuild}/ban/${uid}`, {
    method: 'POST',
    body: JSON.stringify({ reason: reason || 'Banni via le panel' }),
  });
  if (r?.success) { res.textContent = 'Utilisateur banni.'; res.className = 'action-result ok'; }
  else { res.textContent = 'Erreur : vérifiez l\'ID et les permissions du bot.'; res.className = 'action-result err'; }
}

// ── Config check ──────────────────────────────────────────────────────────────
function checkConfig() {
  // Minimal client-side feedback (real check happens server-side)
  const checks = [
    ['cfg-bot', true],
    ['cfg-cid', true],
    ['cfg-cs',  true],
    ['cfg-sk',  true],
    ['cfg-ru',  true],
    ['cfg-oi',  true],
  ];
  checks.forEach(([id]) => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = '<span class="badge enabled">Configuré</span>';
  });
}

// ── Utils ─────────────────────────────────────────────────────────────────────
function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function showToast(msg, type) {
  const t = document.createElement('div');
  t.textContent = msg;
  t.style.cssText = `
    position:fixed;bottom:20px;right:20px;
    background:${type==='ok'?'rgba(59,165,92,0.9)':'rgba(237,66,69,0.9)'};
    color:#fff;padding:10px 18px;border-radius:8px;
    font-size:13px;z-index:9999;
  `;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// ── Boot ───────────────────────────────────────────────────────────────────────
init();
