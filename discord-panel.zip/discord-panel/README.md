# Discord Bot Panel

Panel web dark/gaming pour gérer ton bot Discord, prêt pour Render.

## Fonctionnalités

- Authentification OAuth2 Discord (accès restreint aux owners)
- Statistiques (serveurs, latence, uptime)
- Liste des serveurs accessibles
- Commandes slash enregistrées
- Liste des membres (avec kick)
- Modération : kick & ban depuis le panel
- Liste des bans avec déban en 1 clic

---

## Déploiement sur Render

### 1. Prérequis : Discord Developer Portal

1. Rends-toi sur https://discord.com/developers/applications
2. Sélectionne ton application → **OAuth2**
3. Ajoute une **Redirect URI** :
   ```
   https://<ton-app>.onrender.com/callback
   ```
4. Note ton **Client ID** et **Client Secret**
5. Rends-toi sur **Bot** → copie le **Token**

### 2. Déployer sur Render

**Option A — Avec render.yaml (recommandé)**

1. Push ce dossier sur GitHub
2. Dans Render : New → Blueprint → connecte le repo
3. Render lit `render.yaml` et crée le service automatiquement
4. Renseigne les variables d'environnement (voir ci-dessous)

**Option B — Manuel**

1. Render → New → Web Service
2. Connecte ton repo GitHub
3. Runtime : **Python 3**
4. Build command : `pip install -r requirements.txt`
5. Start command : `gunicorn app:app --bind 0.0.0.0:$PORT --workers 2`
6. Renseigne les variables d'environnement

### 3. Variables d'environnement

| Variable       | Description                                          | Exemple                                         |
|----------------|------------------------------------------------------|-------------------------------------------------|
| `BOT_TOKEN`    | Token de ton bot Discord                             | `MTIz...`                                       |
| `CLIENT_ID`    | ID de l'application Discord                          | `1234567890`                                    |
| `CLIENT_SECRET`| Secret OAuth2                                        | `abc123...`                                     |
| `SECRET_KEY`   | Clé secrète Flask (Render peut la générer)           | clé aléatoire 32+ chars                         |
| `REDIRECT_URI` | URL de callback OAuth (doit matcher Discord)         | `https://discord-bot-panel.onrender.com/callback` |
| `OWNER_IDS`    | IDs Discord autorisés, séparés par des virgules      | `123456789012345678,987654321098765432`          |

### 4. Trouver ton ID Discord

Dans Discord : Paramètres → Avancé → Mode développeur ✓  
Puis clic droit sur ton pseudo → "Copier l'identifiant"

---

## Développement local

```bash
# Installer les dépendances
pip install -r requirements.txt

# Créer un fichier .env (non commité)
cp .env.example .env
# Remplir les valeurs dans .env

# Lancer
python app.py
```

Ajouter `http://localhost:5000/callback` dans les Redirect URIs Discord.

---

## Structure

```
discord-panel/
├── app.py                 # Serveur Flask + routes API
├── requirements.txt
├── render.yaml            # Config déploiement Render
├── templates/
│   ├── dashboard.html     # Panel principal
│   ├── login.html         # Page de connexion OAuth
│   └── unauthorized.html  # Accès refusé
└── static/
    ├── css/style.css      # Thème dark gaming
    └── js/panel.js        # Logique frontend
```
