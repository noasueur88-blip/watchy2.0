import os
import requests
from flask import Flask, render_template, jsonify, redirect, url_for, session, request
from functools import wraps
from datetime import datetime, timezone

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-me-in-production")

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
CLIENT_ID = os.environ.get("CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET", "")
REDIRECT_URI = os.environ.get("REDIRECT_URI", "http://localhost:5000/callback")
DISCORD_API = "https://discord.com/api/v10"
OWNER_IDS = os.environ.get("OWNER_IDS", "").split(",")  # Discord user IDs autorisés

# ── Auth helpers ───────────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

def bot_headers():
    return {"Authorization": f"Bot {BOT_TOKEN}", "Content-Type": "application/json"}

def discord_request(endpoint, method="GET", token=None, **kwargs):
    headers = {"Authorization": f"Bearer {token}"} if token else bot_headers()
    headers["Content-Type"] = "application/json"
    try:
        r = requests.request(method, f"{DISCORD_API}/{endpoint}", headers=headers, timeout=5, **kwargs)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        return {"error": str(e)}

# ── Routes auth ───────────────────────────────────────────────────────────────

@app.route("/login")
def login():
    scopes = "identify guilds"
    return redirect(
        f"https://discord.com/oauth2/authorize"
        f"?client_id={CLIENT_ID}&redirect_uri={REDIRECT_URI}"
        f"&response_type=code&scope={scopes}"
    )

@app.route("/callback")
def callback():
    code = request.args.get("code")
    if not code:
        return "Erreur : code manquant", 400

    data = {
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": REDIRECT_URI,
    }
    r = requests.post(f"{DISCORD_API}/oauth2/token", data=data)
    if r.status_code != 200:
        return f"Erreur OAuth : {r.text}", 400

    tokens = r.json()
    access_token = tokens["access_token"]

    user = discord_request("users/@me", token=access_token)
    if "error" in user or "id" not in user:
        return "Impossible de récupérer l'utilisateur", 400

    if OWNER_IDS and OWNER_IDS[0] and user["id"] not in OWNER_IDS:
        return render_template("unauthorized.html"), 403

    session["user"] = user
    session["access_token"] = access_token
    return redirect(url_for("dashboard"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ── Dashboard ─────────────────────────────────────────────────────────────────

@app.route("/")
@login_required
def dashboard():
    return render_template("dashboard.html", user=session["user"])

# ── API endpoints ─────────────────────────────────────────────────────────────

@app.route("/api/stats")
@login_required
def api_stats():
    guilds = discord_request("users/@me/guilds", token=session.get("access_token")) or []
    guild_count = len(guilds) if isinstance(guilds, list) else 0

    bot_info = discord_request("users/@me") if BOT_TOKEN else {}
    latency = "N/A"

    return jsonify({
        "guilds": guild_count,
        "users": "—",
        "commands_today": "—",
        "latency": latency,
        "uptime": "—",
        "status": "online",
    })

@app.route("/api/guilds")
@login_required
def api_guilds():
    guilds = discord_request("users/@me/guilds", token=session.get("access_token"))
    if isinstance(guilds, list):
        result = []
        for g in guilds[:20]:
            result.append({
                "id": g.get("id"),
                "name": g.get("name"),
                "icon": g.get("icon"),
                "owner": g.get("owner", False),
                "permissions": g.get("permissions"),
            })
        return jsonify(result)
    return jsonify([])

@app.route("/api/guild/<guild_id>/commands")
@login_required
def api_commands(guild_id):
    cmds = discord_request(f"applications/{CLIENT_ID}/guilds/{guild_id}/commands")
    if isinstance(cmds, list):
        return jsonify(cmds)
    global_cmds = discord_request(f"applications/{CLIENT_ID}/commands")
    return jsonify(global_cmds if isinstance(global_cmds, list) else [])

@app.route("/api/guild/<guild_id>/bans")
@login_required
def api_bans(guild_id):
    bans = discord_request(f"guilds/{guild_id}/bans")
    return jsonify(bans if isinstance(bans, list) else [])

@app.route("/api/guild/<guild_id>/ban/<user_id>", methods=["POST"])
@login_required
def api_ban(guild_id, user_id):
    data = request.json or {}
    reason = data.get("reason", "Banni via le panel")
    result = discord_request(
        f"guilds/{guild_id}/bans/{user_id}",
        method="PUT",
        json={"delete_message_seconds": 0, "reason": reason}
    )
    return jsonify({"success": "error" not in result})

@app.route("/api/guild/<guild_id>/ban/<user_id>", methods=["DELETE"])
@login_required
def api_unban(guild_id, user_id):
    result = discord_request(f"guilds/{guild_id}/bans/{user_id}", method="DELETE")
    return jsonify({"success": "error" not in result})

@app.route("/api/guild/<guild_id>/members")
@login_required
def api_members(guild_id):
    limit = request.args.get("limit", 50)
    members = discord_request(f"guilds/{guild_id}/members?limit={limit}")
    if isinstance(members, list):
        result = []
        for m in members:
            u = m.get("user", {})
            result.append({
                "id": u.get("id"),
                "username": u.get("username"),
                "discriminator": u.get("discriminator", "0"),
                "avatar": u.get("avatar"),
                "joined_at": m.get("joined_at"),
                "roles": m.get("roles", []),
                "nick": m.get("nick"),
            })
        return jsonify(result)
    return jsonify([])

@app.route("/api/guild/<guild_id>/roles")
@login_required
def api_roles(guild_id):
    roles = discord_request(f"guilds/{guild_id}/roles")
    return jsonify(roles if isinstance(roles, list) else [])

@app.route("/api/guild/<guild_id>/channels")
@login_required
def api_channels(guild_id):
    channels = discord_request(f"guilds/{guild_id}/channels")
    return jsonify(channels if isinstance(channels, list) else [])

@app.route("/api/guild/<guild_id>/kick/<user_id>", methods=["POST"])
@login_required
def api_kick(guild_id, user_id):
    result = discord_request(f"guilds/{guild_id}/members/{user_id}", method="DELETE")
    return jsonify({"success": "error" not in result})

# ── Sanity check pour Render ──────────────────────────────────────────────────

@app.route("/health")
def health():
    return jsonify({"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
